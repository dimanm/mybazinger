-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 02 2018 г., 23:43
-- Версия сервера: 5.6.41
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `land_form`
--

-- --------------------------------------------------------

--
-- Структура таблицы `floors`
--

CREATE TABLE `floors` (
  `id` int(11) NOT NULL,
  `floor_name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `html` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250 COLLATE=cp1250_bin;

--
-- Дамп данных таблицы `floors`
--

INSERT INTO `floors` (`id`, `floor_name`, `html`) VALUES
(1, 'first-screen', '<div class=\"first-screen sl\">\n			<div class=\"sl__slide\">\n				<div class=\"container\">\n					<div class=\"col-7on12\">\n						<!--1) девиз-->\n						<div class=\"slogan\">Simple, Beautiful <span>and Amazing</span></div>\n						<!--2) параграф-->\n						<div class=\"paragraph\">\n							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eget nunc vitae tellus luctus ullamcorper. Nam porttitor ullamcorper felis. Aenean ornare vestibulum nisi fringilla lacinia. Nullam pulvinar sollicitudin velit id laoreet. Quisque non rhoncus sem.\n						</div>\n						<!--3) кнопки с текстом-->\n						<div class=\"blue-buttons\">\n							<a href=\"#\">download</a> \n							<a href=\"#\">learn more</a>\n						</div>\n						<!--4) иконки-->\n						<div class=\"app-icos\">\n							<div class=\"aavailable\">Aavailable on:</div>\n							<a href=\"#\"><img class=\"app-icos__ios\" src=\"./assets/img/ios1.png\"></a>\n							<a href=\"#\"><img class=\"app-icos__android\" src=\"./assets/img/android1.png\"></a>\n						</div>\n					</div>\n				</div>\n				<img class=\"sl__img\" src=\"./assets/img/first-screen.jpg\">\n			</div>\n			<div class=\"sl__slide\">\n				<div class=\"container\">\n					<div class=\"col-7on12\">\n						<!--1) девиз-->\n						<div class=\"slogan\">Simple, Beautiful <span>and Amazing</span></div>\n						<!--2) параграф-->\n						<div class=\"paragraph\">\n							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eget nunc vitae tellus luctus ullamcorper. Nam porttitor ullamcorper felis. Aenean ornare vestibulum nisi fringilla lacinia. Nullam pulvinar sollicitudin velit id laoreet. Quisque non rhoncus sem.\n						</div>\n						<!--3) кнопки с текстом-->\n						<div class=\"blue-buttons\">\n							<a href=\"#\">download</a> \n							<a href=\"#\">learn more</a>\n						</div>\n						<!--4) иконки-->\n						<div class=\"app-icos\">\n							<div class=\"aavailable\">Aavailable on:</div>\n							<a href=\"#\"><img class=\"app-icos__ios\" src=\"./assets/img/ios1.png\"></a>\n							<a href=\"#\"><img class=\"app-icos__android\" src=\"./assets/img/android1.png\"></a>\n						</div>\n					</div>\n				</div>\n				<img class=\"sl__img\" src=\"./assets/img/first-screen.jpg\">\n			</div>\n			<div class=\"sl__slide\">\n				<div class=\"container\">\n					<div class=\"col-7on12\">\n						<!--1) девиз-->\n						<div class=\"slogan\">Simple, Beautiful <span>and Amazing</span></div>\n						<!--2) параграф-->\n						<div class=\"paragraph\">\n							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eget nunc vitae tellus luctus ullamcorper. Nam porttitor ullamcorper felis. Aenean ornare vestibulum nisi fringilla lacinia. Nullam pulvinar sollicitudin velit id laoreet. Quisque non rhoncus sem.\n						</div>\n						<!--3) кнопки с текстом-->\n						<div class=\"blue-buttons\">\n							<a href=\"#\">download</a> \n							<a href=\"#\">learn more</a>\n						</div>\n						<!--4) иконки-->\n						<div class=\"app-icos\">\n							<div class=\"aavailable\">Aavailable on:</div>\n							<a href=\"#\"><img class=\"app-icos__ios\" src=\"./assets/img/ios1.png\"></a>\n							<a href=\"#\"><img class=\"app-icos__android\" src=\"./assets/img/android1.png\"></a>\n						</div>\n					</div>\n				</div>\n				<img class=\"sl__img\" src=\"./assets/img/first-screen.jpg\">\n			</div>\n		</div>'),
(2, 'features', '<div class=\"site-level\">\n			<div class=\"site-level__name\">summarise the features</div>\n			<div class=\"site-level__about\">summarise what your product is all about</div>\n			<div class=\"row round-box\">\n				<div class=\"col-4\">\n					<a href=\"#\"><img src=\"./assets/img/roundcore1.png\"></a>\n					<div class=\"round-box__name\">Attractive Layout</div>\n					<div class=\"round-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n				<div class=\"col-4\">\n					<a href=\"#\"><img src=\"./assets/img/roundcore2.png\"></a>\n					<div class=\"round-box__name\">Fresh Design</div>\n					<div class=\"round-box__about\">unc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n				<div class=\"col-4\">\n					<a href=\"#\"><img src=\"./assets/img/roundcore3.png\"></a>\n					<div class=\"round-box__name\">multipurpose</div>\n					<div class=\"round-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n				<div class=\"col-4\">\n					<a href=\"#\"><img src=\"./assets/img/roundcore4.png\"></a>\n					<div class=\"round-box__name\">Easy to customize</div>\n					<div class=\"round-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n			</div>\n		</div>'),
(3, 'gallery', '<div class=\"site-level\">\n			<div class=\"site-level__name\">show the gallery</div>\n			<div class=\"site-level__about\">summarise what your product is all about</div>\n			<div class=\"row shot-box\">\n				<div class=\"col-4\">\n					<a href=\"img/cloud1.jpg\" data-fancybox=\"gallery\">\n						<img class=\"shot\" src=\"./assets/img/cloud.png\">			\n						<img class=\"plus\" src=\"./assets/img/plus.png\">\n						<div class=\"shot-name\">screen shot #1</div>				\n					</a>\n					<div class=\"shot-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n				<div class=\"col-4\">\n					<a href=\"img/cloud2.jpg\" data-fancybox=\"gallery\">\n						<img class=\"shot\" src=\"./assets/img/cloud.png\">			\n						<img class=\"plus\" src=\"./assets/img/plus.png\">\n						<div class=\"shot-name\">screen shot #2</div>				\n					</a>\n					<div class=\"shot-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n				<div class=\"col-4\">\n					<a href=\"img/cloud3.jpg\" data-fancybox=\"gallery\">\n						<img class=\"shot\" src=\"./assets/img/cloud.png\">			\n						<img class=\"plus\" src=\"./assets/img/plus.png\">\n						<div class=\"shot-name\">screen shot #3</div>\n					</a>\n					<div class=\"shot-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n				<div class=\"col-4\">\n					<a href=\"img/cloud4.jpg\" data-fancybox=\"gallery\">\n						<img class=\"shot\" src=\"./assets/img/cloud.png\">			\n						<img class=\"plus\" src=\"./assets/img/plus.png\">\n						<div class=\"shot-name\">screen shot #4</div>	\n					</a>\n					<div class=\"shot-box__about\">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam elerisque mi id faucibus iaculis vitae pulvinar.</div>\n				</div>\n			</div>\n		</div>'),
(4, 'video', '<div class=\"row site-video\">\n			<div class=\"col-1\">\n				<a href=\"#\">&#9658</a> \n				<div class=\"site-video__name\">Watch the best Technology <span>in Action<span></div>\n				<div class=\"site-video__paragraph\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eget nunc vitae tellus luctus ullamcorper. Nam porttitor ullamcorper felis at convallis. Aenean ornare vestibulum nisi fringilla lacinia. Nullam pulvinar sollicitudin velit id laoreet. Quisque non </div>\n			</div>\n		</div>'),
(5, 'prices', '<div class=\"site-level\">\n			<div class=\"site-level__name\">choose your price</div>\n			<div class=\"site-level__about\">summarise what your product is all about</div>\n			<div class=\"row vcentering\">		\n				<div class=\"col-3on12 price-box__left\">\n					<div>basic package</div>\n					<div class=\"price\">20$</div>\n					<div>Nullam suscipit vitae</div>\n					<div>Etiam faucibus</div>\n					<div>Vivamus viverra</div>\n					<div><a href=\"\">purchase</a></div>\n				</div>\n				<div class=\"col-4on12 price-box__center\">\n					<div>professional package</div>\n					<div class=\"price\">25$</div>\n					<div>Nullam suscipit vitae</div>\n					<div>Etiam faucibus</div>\n					<div>Vivamus viverra</div>\n					<div>Praesent pharetra</div>\n					<div><a href=\"\">purchase</a></div>\n				</div>\n				<div class=\"col-3on12 price-box__right\">\n					<div>advanced package</div>\n					<div class=\"price\">35$</div>\n					<div>Nullam suscipit vitae</div>\n					<div>Etiam faucibus</div>\n					<div>Vivamus viverra</div>\n					<div><a href=\"\">purchase</a></div>\n				</div>\n			</div>\n		</div>'),
(6, 'testimonials', '<div class=\"site-level site-testimonials\">\n			<div class=\"site-level__name\">Testimonials</div>\n			<div class=\"sl\">\n				<div class=\"sl__slide\">\n					<div class=\"row\">\n						<div class=\"col-6on12\">\n							<img src=\"./assets/img/ava.png\">\n							<div class=\"testimonial\">\n								<div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent lobortis lectus eget libero blandit venenatis. In blandit tortor vel congue malesuada. Suspendisse molestie lobortis lorem dignissim pretium.</div>\n								<div class=\"signature\"> John Doe <br> from some company</div>\n							</div>\n						</div>\n					</div>\n				</div>\n				<div class=\"sl__slide\">\n					<div class=\"row\">\n						<div class=\"col-6on12\">\n							<img src=\"./assets/img/ava.png\">\n							<div class=\"testimonial\">\n								<div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent lobortis lectus eget libero blandit venenatis. In blandit tortor vel congue malesuada. Suspendisse molestie lobortis lorem dignissim pretium.</div>\n								<div class=\"signature\"> John Doe <br> from some company</div>\n							</div>\n						</div>\n					</div>\n				</div>\n				<div class=\"sl__slide\">\n					<div class=\"row\">\n						<div class=\"col-6on12\">\n							<img src=\"./assets/img/ava.png\">\n							<div class=\"testimonial\">\n								<div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent lobortis lectus eget libero blandit venenatis. In blandit tortor vel congue malesuada. Suspendisse molestie lobortis lorem dignissim pretium.</div>\n								<div class=\"signature\"> John Doe <br> from some company</div>\n							</div>\n						</div>\n					</div>\n				</div>\n			</div>\n		</div>');

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(30) DEFAULT NULL,
  `message` text,
  `t_send` varchar(19) DEFAULT NULL,
  `t_open` varchar(19) DEFAULT NULL,
  `dt` varchar(19) DEFAULT NULL,
  `psw_img` varchar(255) DEFAULT NULL,
  `salt` varchar(10) DEFAULT NULL,
  `tel` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `subject`, `message`, `t_send`, `t_open`, `dt`, `psw_img`, `salt`, `tel`) VALUES
(1, 'наташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 15:27:58', '2018-12-02 15:27:17', '00.00.00 00:00:41', '504fd23c938cd7ff749d9e357326681f', '5q0:Z', '+7(333) 333-3333'),
(2, 'димка', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 15:29:17', '2018-12-02 15:29:03', '00.00.00 00:00:14', '2043140a1495ebcedb0dc103923b07b5', '~HFFl', NULL),
(3, 'василий', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 15:30:13', '2018-12-02 15:30:01', '00.00.00 00:00:12', '5f3bc5639e2ec7c9cd0dc85e1d7686c8', '!Mw5%0', '+7(333) 333-3333'),
(4, 'наташаz x x', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:04:37', '2018-12-02 22:04:24', '00.00.00 00:00:13', 'de3ed106d6e1f07e6907735fe8fbb1ac', 'i`N^1', NULL),
(5, 'наташаz xd x', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:05:20', '2018-12-02 22:04:24', '00.00.00 00:00:56', '4589762ce94b9139162d6ba9235892eb', 'Zj^_04|', NULL),
(6, 'rergegerg', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:07:10', '2018-12-02 22:07:04', '00.00.00 00:00:06', 'a28f1edebe19e2b05b3b8a57e48633c1', 'Lj@P=Er', NULL),
(7, 'rergegderg', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:08:29', '2018-12-02 22:07:04', '00.00.00 00:01:25', '51d1eb67b8c510f805f2edd203e0e194', 'm(Kh/#b>', NULL),
(8, 'rergegdergd', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:09:13', '2018-12-02 22:07:04', '00.00.00 00:02:09', 'e189ab2d8343b7852b41ba75e2249949', '.>.7Y', NULL),
(9, 'd наташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:11:51', '2018-12-02 22:11:45', '00.00.00 00:00:06', '6e91572e58974b4a7f153ebc56e5cc05', 'fn}Fu&a', NULL),
(10, 'd натаtша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:13:29', '2018-12-02 22:11:45', '00.00.00 00:01:44', '37db5007a8c30909c8d5b9ecd4f750d6', '6Y[sECFe', NULL),
(11, 'василийeeee', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:14:12', '2018-12-02 22:14:04', '00.00.00 00:00:08', '058405f81af17d98fd88e76ae77303ba', 'W\"ae:Q', NULL),
(12, 'наcccccccccташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:25:22', '2018-12-02 22:25:15', '00.00.00 00:00:07', '1d06396ad82aae71ae73bdb1238ba333', 'l67]', NULL),
(13, 'наddddташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:25:44', '2018-12-02 22:25:40', '00.00.00 00:00:04', '106e091460c4e13216f34cc0a0d7a973', 'AFf}&#_~', NULL),
(14, 'наташаz x xe', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:36:59', '2018-12-02 22:36:37', '00.00.00 00:00:22', '345bd47374ca4f485821cdaaf406292f', '%[C-Fb', NULL),
(15, 'натаssssssssssша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:39:33', '2018-12-02 22:39:23', '00.00.00 00:00:10', 'ee31d909c5dea152a67dc59f1ee25804', 'MfH;6c', NULL),
(16, 'нат dfd аша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:49:23', '2018-12-02 22:49:18', '00.00.00 00:00:05', '6ceb813fe3fd367d44befe51016b5502', 'N<t-xB>', NULL),
(17, 'наededededташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:49:43', '2018-12-02 22:49:38', '00.00.00 00:00:05', 'e750cd3c66b19c02955f43cc8842cb03', 'K$bcK[sb', NULL),
(18, 'нeeeeeeeeeeташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:50:58', '2018-12-02 22:50:39', '00.00.00 00:00:19', 'f204440e8d344a2b65f84983f222b5c8', 'rBBQu', NULL),
(19, 'василwefwfewfий', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:52:10', '2018-12-02 22:52:04', '00.00.00 00:00:06', '7ecc04702598184beaac0468497f0338', 'v5hH', NULL),
(20, 'наd таша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:53:22', '2018-12-02 22:53:17', '00.00.00 00:00:05', '16e646b6dbedccd81376aa515295de66', '~~~afM+!', NULL),
(21, 'cdcsd наташа', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:54:39', '2018-12-02 22:54:29', '00.00.00 00:00:10', 'c1aa938df071f1b30c46c2de8e7e2999', 'gk99f`lH', NULL),
(22, 'вsvsdvsdvsvасилий', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:55:11', '2018-12-02 22:54:58', '00.00.00 00:00:13', '50cbe969a8e900c0ab4db4f82779acca', '{Q(C\"7', NULL),
(23, 'наташаsdvdvsd', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 22:55:56', '2018-12-02 22:55:49', '00.00.00 00:00:07', '47962fb3be2bd2a9c2bd51699f52d00b', 'dIOI', NULL),
(24, ' ч  чыыыыыыы', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 23:03:13', '2018-12-02 23:03:06', '00.00.00 00:00:07', '97f450ec527033f5435fc8376f853042', 'BqLwwc', NULL),
(25, 'натv v v аша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 23:08:54', '2018-12-02 23:08:48', '00.00.00 00:00:06', '9305a5ed82870558f68895d0daea93e1', 'T-0}', NULL),
(26, ' w  wwwwwwwwwwwww', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 23:09:56', '2018-12-02 23:09:51', '00.00.00 00:00:05', '3e20e2b80607cb14d45316cd13d1b760', 'e(HJ', NULL),
(27, 'ната       ша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 23:14:24', '2018-12-02 23:14:13', '00.00.00 00:00:11', 'dd5613994fd7300da70ef5ac428a813c', 'qi1-@', NULL),
(28, 'натregrge аша', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 23:20:01', '2018-12-02 23:19:34', '00.00.00 00:00:27', 'fdf32ed94904c830557de04ee928d711', 'fG(]8{', NULL),
(29, 'димака', 'dimitry.myagkov@yandex.ru', '', '', '2018-12-02 23:42:32', '2018-12-02 23:42:15', '00.00.00 00:00:17', 'abfd049fe28cdc6e546a6c1872af6fa3', '`1c>', NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `floors`
--
ALTER TABLE `floors`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `floors`
--
ALTER TABLE `floors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
